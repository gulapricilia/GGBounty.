/**
 * BLS12-381 key generation and signing.
 *
 * This mirrors plugin/typescript/tutorial/src/rpc_test.ts `signBLS()` exactly:
 *   - "long signatures" variant (G1 public keys, G2 signatures), matching the Go node's
 *     kyber bdn.Scheme
 *   - DST: BLS_SIG_BLS12381G2_XMD:SHA-256_SSWU_RO_NUL_ (built into @noble/curves' longSignatures)
 *   - Same library (@noble/curves/bls12-381) the tutorial itself uses for test signing,
 *     so signatures produced here are verified by the same code path Canopy already exercises.
 *
 * Verified against the real published source for the installed range (package.json pins
 * "@noble/curves": "^1.6.0"):
 *   - `longSignatures.getPublicKey(privateKey)` returns the serialized public key as a
 *     Uint8Array directly - confirmed by every real usage example for this version line,
 *     e.g. the package's own 1.6.0 README (`const publicKey = bls.getPublicKey(privateKey)`)
 *     and its aggregation example (`bls.aggregatePublicKeys([...rawKeys])`). There is no
 *     `PublicKey` static/serialization step - that was an invented API in the previous
 *     version of this file and has been removed.
 *   - `longSignatures.hash(message)` / `.sign(hashedPoint, privateKey)` return a curve Point,
 *     which DOES require explicit serialization via `longSignatures.Signature.toBytes(point)`
 *     - this part was already correct, and is used verbatim from
 *     tutorial/src/rpc_test.ts's `signBLS()`.
 *   - `bls12_381.utils.randomPrivateKey()` is the documented private-key generator at this
 *     version (see the package's aggregation example using the same call).
 */

import { bls12_381 } from '@noble/curves/bls12-381';
import { addressFromPublicKey } from './address';

export interface KeyPair {
    privateKey: Uint8Array; // 32 bytes
    publicKey: Uint8Array; // G1 public key bytes (long-signature scheme)
    address: Uint8Array; // 20 bytes, sha256(publicKey)[:20]
}

/** Generate a brand-new BLS12-381 keypair using a CSPRNG. */
export function generateKeyPair(): KeyPair {
    const privateKey = bls12_381.utils.randomPrivateKey();
    return keyPairFromPrivateKey(privateKey);
}

/** Reconstruct a keypair (and address) from an existing private key, e.g. on import. */
export function keyPairFromPrivateKey(privateKey: Uint8Array): KeyPair {
    if (privateKey.length !== 32) {
        throw new Error('invalid private key: expected 32 bytes');
    }
    // getPublicKey() already returns the serialized (compressed) public key bytes - no
    // separate Point/serialization step, unlike signature production below.
    const publicKey = bls12_381.longSignatures.getPublicKey(privateKey);
    const address = addressFromPublicKey(publicKey);
    return { privateKey, publicKey, address };
}

/**
 * Sign arbitrary bytes (the deterministic protobuf-encoded Transaction, signature field
 * omitted - see tx.ts) with the long-signature (G2) BLS scheme.
 */
export function signBLS(privateKey: Uint8Array, message: Uint8Array): Uint8Array {
    const hashedPoint = bls12_381.longSignatures.hash(message);
    const signaturePoint = bls12_381.longSignatures.sign(hashedPoint, privateKey);
    return bls12_381.longSignatures.Signature.toBytes(signaturePoint);
}
